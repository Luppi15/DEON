<?php

declare(strict_types=1);

namespace DEON\Mvc\Controller;

interface Controller
{
    public function processaRequisicao(): void;

}
