<?php
require_once __DIR__ . '/inicio-html.php';
?>
<div class="error__404__container">
    <div class="error--404--text">
        <span>Infelizmente a pagina que esta procurando não existe ou foi excluida, clique na imagem a baixo para ir para pagina inicial.</span>
    </div>
    <a href="/" class="error--404--image">
        <img src="img/others/404DEON.png">
    </a>
</div>
